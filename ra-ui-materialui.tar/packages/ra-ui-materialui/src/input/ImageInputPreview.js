import FileInputPreview from './FileInputPreview';
export default FileInputPreview;
